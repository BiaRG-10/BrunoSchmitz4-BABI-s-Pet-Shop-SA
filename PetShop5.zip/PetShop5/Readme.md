Notas do dia 26/05;
Por: Bruno;

Com relação aos códigos, no intervalo de tempo do dia 25/06 à 26/05, realizei o reparo dos arquivos valida da pasta valida. Eles estavam com problemas de redirecionamento de pastas e páginas. Fiz o reparo e teste, tudo está funcionando corretamente, porém sugiro qe seja feito uma verificação das pastas novamente (após termos os arquivos e projetos idênticos, o que ocorrerá quando fizermos o versionamento do código e envio ao GitHub pelo Gib Bash).

//
Páginas reparadas:
pasta valida-
- valida_cadastro.php
- valida_login.php
- valida_pet.php
- valida_servico.php

pags-
- colaborador.php

adm-
- dashboard.php

//

Obs: 
Link do repositório do projeto no GiHub: https://github.com/BrunoSchmitz4/PetShop5

--

Notas do dia 26/05;
Por: Bruno;

Foi criado a página clientelogged.php, que, ao fazer o login (conta de cliente), redireciona para esta página. Nela, o botão login foi desabilitado por questões de redundâncias e colocado em seu lugar, um "echo" (função php) que dá as boas-vindas ao usuário logado, eqnuanto que aparece o nome do mesmo (usado apra verificação de log corretamente feito).
A página valida_login.php estava com problema novamente no redirecionamento para a página do index.php.

//
Páginas reparadas:
pasta valida-
- valida_login.php

pags-
- cliente.logged 